
__all__ = ['APEX_PANEL', 'BISECT_PANEL', 'BISECT_PREMIUM', 'SHOCKBYTE_PANEL', 'PEBBLEHOST_PANEL']

APEX_PANEL = 'https://panel.apexminecrafthosting.com/api.php'
BISECT_PANEL = 'https://panel.bisecthosting.com/api.php'
BISECT_PREMIUM = 'https://premium.bisecthosting.com/api.php'
SHOCKBYTE_PANEL = 'https://panel.shockbyte.com/api.php'
PEBBLEHOST_PANEL = 'https://panel.pebblehost.com/api.php'
